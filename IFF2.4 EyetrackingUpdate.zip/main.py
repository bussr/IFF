""" Coded by Matthew Nebel for the CogWorks IFF experiment """

import pygame, sys, math, numpy, random, time, inputbox
import picture
from pygame.locals import *
from pycogworks.cogworld import *
import argparse

pygame.init()

parser = argparse.ArgumentParser(formatter_class=argparse.ArgumentDefaultsHelpFormatter)
parser.add_argument('--condition', action="store", dest="condition", help='Task Condition', metavar='COND')
parser.add_argument('--port', action="store", dest="port", help='CogWorld RPC port')
args = parser.parse_args()

cw = None
if args.port:
    cw = CogWorld('localhost',args.port,'IFF')
    ret = cw.connect()
    if (ret!=None):
        print 'CogWorld %s' % (ret)
        sys.exit()
    else:
        print 'Connected to CogWorld %s' % (cw.cwGetVersion())

# Load in variables from the config file
execfile('config.txt')

# INITIALIZE ALL GRAPHICAL ASSET #

# Initialize game screen
screen = pygame.display.set_mode(ASPECT)
if FULLSCREEN:
    screen = pygame.display.set_mode(ASPECT, pygame.FULLSCREEN)

#Load in the list of backgrounds
bgs = []
bgs.append(picture.Picture("backgrounds/background.png", (0,0), 1))

# Load in the list of bodies
bodies = []
bodies.append(picture.Picture("soldiers/soldier.png", (0,0), 1))
if SOLDIERTYPES:
    bodies.append(picture.Picture("soldiers/asian_soldier.png", (0,0), 1))
    bodies.append(picture.Picture("soldiers/black_soldier.png", (0,0), 1))

# Load in their associated arms
arms = []
arms.append(picture.Picture("soldiers/arms.png", (0,0), 1))
arms.append(picture.Picture("soldiers/asian_arms.png", (0,0), 1))
arms.append(picture.Picture("soldiers/black_arms.png", (0,0), 1))

# Load in the list of armbands
bands = []
bands.append(picture.Picture("armbands/armband_striped.png", (0,0), 1))
bands.append(picture.Picture("armbands/armband_solid.png", (0,0), 1))

# Load in the list of held pictures
held = []
held.append(picture.Picture("held/bag.png", (0,0), 1))
held.append(picture.Picture("held/bucket.png", (0,0), 1))

# Load in the list of helmets
helmets = []
helmets.append(picture.Picture("helmets/green.png", (0,0), 1))
helmets.append(picture.Picture("helmets/beige.png", (0,0), 1))

# The 'expand' function create a larger background for presented messages
def expand(surf):
    rect = surf.get_rect()
    newsurf = pygame.Surface((rect.width+MSGBORDER, rect.height+MSGBORDER))
    newsurf.fill(BGCOLOR)
    newsurf.blit(surf, (MSGBORDER/2, MSGBORDER/2))
    return newsurf

# Initialize fonts and create messages
font = pygame.font.Font(None, 45)
fcMsg = expand(font.render('Correct: was a Friend', 1, MSGCOLOR))
ecMsg = expand(font.render('Correct: was an Enemy', 1, MSGCOLOR))
fwMsg = expand(font.render('Incorrect: was an Enemy', 1, MSGCOLOR))
ewMsg = expand(font.render('Incorrect: was a Friend', 1, MSGCOLOR))
ootfMsg = expand(font.render('Out of time: was a Friend', 1, MSGCOLOR))
ooteMsg = expand(font.render('The enemy soldier shot you!', 1, MSGCOLOR))
blockMsg = expand(font.render('Block Complete!', 1, MSGCOLOR))
spaceMsg = expand(font.render('Press Space Bar to Continue', 1, MSGCOLOR))
warning1Msg = expand(font.render('You responded before any cues were shown.', 1, MSGCOLOR))
warning2Msg = expand(font.render('Please try to judge accurately based on the cues.', 1, MSGCOLOR))
warning3Msg = expand(font.render('The trial will restart in a few seconds.', 1, MSGCOLOR))

# MISCELLANIOUS INITIALIZATION #

clock=pygame.time.Clock()

# Initialize trials list
presentations = [(0,1,2), (0,2,1), (1,0,2), (1,2,0), (2,0,1), (2,1,0)]
combinations = []
for i in range(0,NUMVARIETIES):
    for j in range(0,NUMVARIETIES):
        for k in range(0,NUMVARIETIES):
            combinations.append((i,j,k))
trials = []
for presentation in presentations:
    for combination in combinations:
        trials.append((presentation[0] * NUMVARIETIES + combination[0], presentation[1] * NUMVARIETIES + combination[1], presentation[2] * NUMVARIETIES + combination[2]))

blockNum = 0

# DEFINE HELPER FUNCTIONS

# Function to assist with drawing the screen
def draw_screen(bgID, soldierID, bandID, heldID, helmID):
    screen.fill((0,0,0))
    bg = bgs[bgID].image.copy()
    soldier = bodies[soldierID].image.copy()
    if bandID >= 0:
        soldier.blit(bands[bandID].image, bands[bandID].loc)
    if heldID >= 0:
        soldier.blit(held[heldID].image, held[heldID].loc)
    if helmID >= 0:
        soldier.blit(helmets[helmID].image, helmets[helmID].loc)
    soldier.blit(arms[soldierID].image, arms[soldierID].loc)
    bg.blit(soldier, bodies[soldierID].loc)
    screen.blit(bg, (0,0))
    pygame.display.flip()
    
# Function to punish users for inputting an answer before any cues are displayed
def early_lockout():
    screen.fill((0,0,0))
    screen.blit(warning1Msg, (screen.get_width()/2 - warning1Msg.get_width()/2, screen.get_height()/2 - warning1Msg.get_height()/2 - MSGOFFSET))
    screen.blit(warning2Msg, (screen.get_width()/2 - warning2Msg.get_width()/2, screen.get_height()/2 - warning2Msg.get_height()/2))
    screen.blit(warning3Msg, (screen.get_width()/2 - warning3Msg.get_width()/2, screen.get_height()/2 - warning3Msg.get_height()/2 + MSGOFFSET))

    pygame.display.flip()
    pygame.time.delay(LOCKOUT)
    for event in pygame.event.get():
        continue  
    draw_screen(bgID, soldierID, trialState[ARMBAND], trialState[HELD], trialState[HELMET])
    return pygame.time.get_ticks()
    
# BEGIN EXPERIMENT #

# Prompt for Subject Number
subnum = inputbox.ask(screen, "Subject Number")

# Flag that determines whether the enemy can shoot first
shootFirst = True
# Prompt for whether enemies shoot first or not
sf = inputbox.ask(screen, "a or b")
if sf == "a":
    shootFirst = False
    
# Decides which items are associated with being an enemy (1) for each slot
# THIS WILL ONLY BE RELEVANT FOR 3 SLOTS WITH 2 VARIETIES EACH
enemyPossibilities = ((0,1) , (1,0))
enemyCombinations = []
for i in range(0, SLOTS-1):
    for j in range (0, SLOTS-1):
        for k in range(0, SLOTS-1):
            enemyCombinations.append((enemyPossibilities[i], enemyPossibilities[j], enemyPossibilities[k]))
# Prompt for the friend/enemy item grouping number
setnum = int(inputbox.ask(screen, "1 to 8"))
enemySet = enemyCombinations[setnum-1]

# Open output text file
log = open(time.strftime("%Y_%m%d_%H%M") + '_' + str(subnum) + '_' + sf + '_' + str(setnum) + '.txt', 'w')

# Wait for input before starting trials
screen.fill((0,0,0))
screen.blit(spaceMsg, (screen.get_width()/2 - spaceMsg.get_width()/2, screen.get_height()/2 - spaceMsg.get_height()/2))
pygame.display.flip()
space = False
while not space:
    clock.tick(500)
    for event in pygame.event.get():
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE:
                space = True

# MAIN EXPERIMENT LOOP #
 
while blockNum < NUMBLOCKS:
    # Initialize list of trials for this block
    currentTrials = trials[:]
    random.shuffle(currentTrials)
    

    if cw:
        cw.cwLogInfo([str(subnum), str(blockNum), str(pygame.time.get_ticks()), "blockstart"])
    else:
        log.write(str(subnum) + " " + str(blockNum) + " " + str(pygame.time.get_ticks()) + " blockstart\n")

    trialNum = 0
    
    correct = 0
    shotFriend = 0
    enemyShot = 0
    helpedEnemy = 0
    
    for trial in currentTrials:
        # Determine friend or foe status
        friend = False
        fstatus = "enemy"
        enemySum = 0
        for i in range(0, len(trial)):
            enemySum += enemySet[i][trial[i]%NUMVARIETIES]
        if enemySum < (SLOTS+1)/2:
            friend = True
            fstatus = "friend"
            
        # If enemy and proper condition, calculate early end
        endtrial = ENDTIME
        if not friend and shootFirst:
            endtrial = ENDTIME - (math.exp(DISTRIBUTION*random.gauss(0, 1)) * 1000)
            while endtrial < STEPTIME + 500:
                endtrial = ENDTIME - (math.exp(DISTRIBUTION*random.gauss(0, 1)) * 1000)
        
        # Set timekeeping variables
        startTime = pygame.time.get_ticks()

        ## Example of how to log with CogWorld Module ~RMH
        if cw:
            cw.cwLogInfo([str(subnum),str(blockNum),str(trialNum),fstatus,str(startTime),'trialstart',str(endtrial)])
        else:
            log.write(str(subnum) + " " + str(blockNum) + " " + str(trialNum) + " " + fstatus + " " + str(startTime) + " trialstart " + str(endtrial) +"\n") 
        
        # Randomly pick a background and soldier image to use for this trial
        bgID = random.randint(0, len(bgs)-1)
        soldierID = random.randint(0, len(bodies)-1)
        
        # Initialize the solder to be holding nothing
        trialState = [-1, -1, -1]
        trialStep = 0
        
        # Initialize screen
        draw_screen(bgID, soldierID, trialState[ARMBAND], trialState[HELD], trialState[HELMET])
        
        # Flow control variable
        trialRun = True
        
        while trialRun:
            clock.tick(500)
            currentTime = pygame.time.get_ticks()
            
            # If enough time has passed since the last item was presented, show the next one depending on the block and trial
            if currentTime - startTime > STEPTIME * (trialStep+1) and trialStep < TIMEOUT:
                ptype = "armband"
                pvariety = armbandTypes[trial[trialStep]%NUMVARIETIES]
                slot = 0
                if trial[trialStep] > NUMVARIETIES - 1 and trial[trialStep] < NUMVARIETIES * 2:
                    ptype = "held"
                    pvariety = heldTypes[trial[trialStep]%NUMVARIETIES]
                    slot = 1
                elif trial[trialStep] > NUMVARIETIES * 2 - 1:
                    ptype = "helmet"
                    pvariety = helmetTypes[trial[trialStep]%NUMVARIETIES]
                    slot = 2
                penemy = "friendcue"
                if enemySet[trialStep][trial[trialStep]%NUMVARIETIES] == 1:
                    penemy = "enemycue"
                    
                if cw:
                    cw.cwLogInfo([str(subnum), str(blockNum), str(trialNum), str(trialStep), fstatus, str(currentTime), ptype, pvariety, penemy])
                else:
                    log.write(str(subnum) + " " + str(blockNum) + " " + str(trialNum) + " " + str(trialStep) + " " + fstatus + " " + str(currentTime) + " " + ptype + " " + pvariety + " " + penemy + "\n")

                trialState[slot] = trial[trialStep]%2
                trialStep+=1
                draw_screen(bgID, soldierID, trialState[ARMBAND], trialState[HELD], trialState[HELMET])
                
            # If the trial reaches a given end time, cut it off
            if currentTime - startTime > endtrial:
                screen.fill((0,0,0))
                
                if cw:
                    cw.cwLogInfo([str(subnum), str(blockNum), str(trialNum), str(trialStep), fstatus, str(currentTime), "timeout"])
                else:
                    log.write(str(subnum) + " " + str(blockNum) + " " + str(trialNum) + " " + str(trialStep) + " " + fstatus + " " + str(currentTime) + " timeout\n")
                    
                if friend:
                    screen.blit(ootfMsg, (screen.get_width()/2 - ootfMsg.get_width()/2, screen.get_height()/2 - ootfMsg.get_height()/2))
                else:
                    screen.blit(ooteMsg, (screen.get_width()/2 - ooteMsg.get_width()/2, screen.get_height()/2 - ooteMsg.get_height()/2))
                    enemyShot += 1
                if TRIALPAUSE:
                    pygame.display.flip()
                    pygame.time.delay(TRIALPAUSE)
                else:
                    screen.blit(spaceMsg, (screen.get_width()/2 - spaceMsg.get_width()/2, screen.get_height()/2 - spaceMsg.get_height()/2 + MSGOFFSET))
                    pygame.display.flip()
                    space = False
                    while not space:
                        clock.tick(500)
                        for event in pygame.event.get():
                            if event.type == pygame.KEYDOWN:
                                if event.key == pygame.K_SPACE:
                                    space = True
                for event in pygame.event.get():
                    continue
                trialRun = False
                    
            # Accept user input
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    log.close()
                    pygame.quit()
                    sys.exit(0)
                
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        log.close()
                        pygame.quit()
                        sys.exit(0)
                    # If 'f' is pressed for 'friend' respond accordingly
                    if event.key == pygame.K_f:
                        # If the user responds too quickly, display warning, lockout, and reset trial
                        if trialStep == 0:
                            startTime = early_lockout()
                            if cw:
                                cw.cwLogInfo([str(subnum), str(blockNum), str(trialNum), fstatus, str(startTime), "trialstart", str(endtrial)])
                            else:
                                log.write(str(subnum) + " " + str(blockNum) + " " + str(trialNum) + " " + fstatus + " " + str(startTime) + " trialstart " + str(endtrial) +"\n")

                        else:
                            if cw:
                                cw.cwLogInfo([(str(subnum), str(blockNum), str(trialNum), str(trialStep), fstatus, str(currentTime), "friend")])
                            else:
                                log.write((str(subnum) + " " + str(blockNum) + " " + str(trialNum) + " " + str(trialStep) + " " + fstatus + " " + str(currentTime) + " friend\n"))

                            screen.fill((0,0,0))
                            if friend:
                                screen.blit(fcMsg, (screen.get_width()/2 - fcMsg.get_width()/2, screen.get_height()/2 - fcMsg.get_height()/2))
                                correct += 1
                            else:
                                screen.blit(fwMsg, (screen.get_width()/2 - fwMsg.get_width()/2, screen.get_height()/2 - fwMsg.get_height()/2))
                                helpedEnemy += 1
                            if TRIALPAUSE:
                                pygame.display.flip()
                                pygame.time.delay(TRIALPAUSE)
                            else:
                                screen.blit(spaceMsg, (screen.get_width()/2 - spaceMsg.get_width()/2, screen.get_height()/2 - spaceMsg.get_height()/2 + MSGOFFSET))
                                pygame.display.flip()
                                space = False
                                while not space:
                                    clock.tick(500)
                                    for event in pygame.event.get():
                                        if event.type == pygame.KEYDOWN:
                                            if event.key == pygame.K_SPACE:
                                                space = True
                            for event in pygame.event.get():
                                continue                                               
                            trialRun = False
                    # If 'j' is pressed for 'enemy' respond accordingly
                    elif event.key == pygame.K_j:
                        # If the user responds too quickly, display warning, lockout, and reset trial
                        if trialStep == 0:
                            startTime = early_lockout()
                            if cw:
                                cw.cwLogInfo([str(subnum), str(blockNum), str(trialNum), fstatus, str(startTime), "trialstart", str(endtrial)])
                            else:
                                log.write(str(subnum) + " " + str(blockNum) + " " + str(trialNum) + " " + fstatus + " " + str(startTime) + " trialstart " + str(endtrial) +"\n")
                                
                        else:
                            if cw:
                                cw.cwLogInfo([str(subnum), str(blockNum), str(trialNum), str(trialStep), fstatus, str(currentTime), "enemy"])
                            else:
                                log.write((str(subnum) + " " + str(blockNum) + " " + str(trialNum) + " " + str(trialStep) + " " + fstatus + " " + str(currentTime) + " enemy\n"))

                            screen.fill((0,0,0))
                            if not friend:
                                screen.blit(ecMsg, (screen.get_width()/2 - ecMsg.get_width()/2, screen.get_height()/2 - ecMsg.get_height()/2))
                                correct += 1
                            else:
                                screen.blit(ewMsg, (screen.get_width()/2 - ewMsg.get_width()/2, screen.get_height()/2 - ewMsg.get_height()/2))
                                shotFriend += 1
                            if TRIALPAUSE:
                                pygame.display.flip()
                                pygame.time.delay(TRIALPAUSE)
                            else:
                                screen.blit(spaceMsg, (screen.get_width()/2 - spaceMsg.get_width()/2, screen.get_height()/2 - spaceMsg.get_height()/2 + MSGOFFSET))
                                pygame.display.flip()
                                space = False
                                while not space:
                                    clock.tick(500)
                                    for event in pygame.event.get():
                                        if event.type == pygame.KEYDOWN:
                                            if event.key == pygame.K_SPACE:
                                                space = True
                            for event in pygame.event.get():
                                continue
                            trialRun = False
                        
        trialNum += 1
                        
    # clear screen and display feedback for block
    blockNum += 1
    screen.fill((0,0,0))
    friendsShotMsg = expand(font.render('Number of friends shot: ' + str(shotFriend), 1, MSGCOLOR))
    shotYouMsg = expand(font.render('Number of enemies that shot you: ' + str(enemyShot), 1, MSGCOLOR))
    letInMsg = expand(font.render('Number of enemies you let into the base: ' + str(helpedEnemy), 1, MSGCOLOR))
    correctMsg = expand(font.render('Correctly identified ' + str(correct) + ' out of ' + str(len(trials)) + \
        ' for an accuracy ratio of '+ str(int(correct/float(len(trials)) * 100.0)) + '%', 1, MSGCOLOR))
    screen.blit(blockMsg, (screen.get_width()/2 - blockMsg.get_width()/2, screen.get_height()/2 - blockMsg.get_height()/2 -  3 * MSGOFFSET))
    screen.blit(friendsShotMsg, (screen.get_width()/2 - friendsShotMsg.get_width()/2, screen.get_height()/2 - friendsShotMsg.get_height()/2 -  2 * MSGOFFSET))
    screen.blit(shotYouMsg, (screen.get_width()/2 - shotYouMsg.get_width()/2, screen.get_height()/2 - shotYouMsg.get_height()/2 -  MSGOFFSET))
    screen.blit(letInMsg, (screen.get_width()/2 - letInMsg.get_width()/2, screen.get_height()/2 - letInMsg.get_height()/2))
    screen.blit(correctMsg, (screen.get_width()/2 - correctMsg.get_width()/2, screen.get_height()/2 - correctMsg.get_height()/2 + MSGOFFSET))
    # either wait the designated amount of time or wait for the space bar
    if BLOCKPAUSE:
        pygame.display.flip()
        pygame.time.delay(BLOCKPAUSE)
    else:
        screen.blit(spaceMsg, (screen.get_width()/2 - spaceMsg.get_width()/2, screen.get_height()/2 - spaceMsg.get_height()/2 + 2 * MSGOFFSET))
        pygame.display.flip()
        space = False
        while not space:
            clock.tick(500)
            for event in pygame.event.get():
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_SPACE:
                        space = True

log.close()

screen.fill((0,0,0))
completeMsg = expand(font.render('Experiment complete!', 1, MSGCOLOR))
notifyMsg = expand(font.render('Please notify the experimenter.', 1, MSGCOLOR))
screen.blit(completeMsg, (screen.get_width()/2 - completeMsg.get_width()/2, screen.get_height()/2 - completeMsg.get_height()/2))
screen.blit(notifyMsg, (screen.get_width()/2 - notifyMsg.get_width()/2, screen.get_height()/2 - notifyMsg.get_height()/2 + MSGOFFSET))
pygame.display.flip()
space = False
while not space:
    clock.tick(500)
    for event in pygame.event.get():
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE:
                space = True

pygame.quit()
